<?php

namespace AC\Plugin;

interface Install {

	public function install();

}