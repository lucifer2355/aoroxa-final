<?php

namespace AC\Asset;

interface Enqueueables {

	/**
	 * @return Assets
	 */
	public function get_assets();

}